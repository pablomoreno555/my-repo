import rclpy
from rclpy.node import Node
from simple_pid import PID
from std_msgs.msg import Float64, Bool
from geometry_msgs.msg import Point

from moreno_5646698_assignment3_interface.srv import EndEffectorPosition

class MotorXControllerNode(Node):

    def __init__(self):
        super().__init__("motor_x_controller")

        # position variable
        self.x_pos = 0
        # PID controller
        self.pid = PID(5.0, 0.01, 0.05)
        
        # Update frequency (equivalent to publisher rate)
        self.dt = 0.01
        self.pid.sample_time = self.dt

        # Position error threshold and control saturation value
        self.control_clip_value = 100
        self.threshold = 1


        self.client = self.create_client(EndEffectorPosition, '/end_effector_position')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service /end_effector_position not available, waiting again...')
        self.request = EndEffectorPosition.Request()

        
        # Position publisher 
        self.pos_publisher = self.create_publisher(Float64, '/motor_x', 10)
        self.ack_publisher = self.create_publisher(Bool, "/ack_x", 10)
        # Setpoint subscriber
        self.setpoint_subscriber = self.create_subscription(Point, "/controller_setpoint", self.set_target_point, 10)


    def send_request(self):

        self.future = self.client.call_async(self.request)
        return self.future
    
    
    def initialize_ee_position(self, ee_init_pos: Point):

        self.x_pos = ee_init_pos.x
    

    # Reset PID target point and start new control loop timer
    def set_target_point(self, msg):
        # Reset to clear previous errors
        self.pid.reset()
        # Set new target point 
        self.pid.setpoint = msg.x
        self.get_logger().info('New target position {0}: set'.format(self.pid.setpoint))
        # Timer for control loop callback        
        self.timer = self.create_timer(self.dt, self.control_loop_callback)

    # Control loop cycle callback
    def control_loop_callback(self):
        # Compute control based on current state value
        control = self.pid(self.x_pos)
        
        # Saturate control input if necessary (optional)
        if control > self.control_clip_value:
            control = self.control_clip_value
        elif control < -self.control_clip_value:
            control = -self.control_clip_value
        self.get_logger().info('Control input: {0}'.format(control))

        # Update position based on control
        self.x_pos += control * self.dt
        self.get_logger().info('Current position: {0}'.format(self.x_pos))

        # Publish updated motor position
        pos_msg = Float64()
        pos_msg.data = self.x_pos
        self.pos_publisher.publish(pos_msg)
        
        # Cancel control loop if position is reached
        if abs(self.x_pos - self.pid.setpoint) < self.threshold:
            self.get_logger().info('Target position {0}: reached'.format(self.pid.setpoint))
            self.timer.cancel()

            # Send ack message
            ack_msg = Bool()
            ack_msg.data = True
            self.ack_publisher.publish(ack_msg)


def main(args=None):
    rclpy.init(args=args)
    controller = MotorXControllerNode()

    future = controller.send_request()
    rclpy.spin_until_future_complete(controller, future)

    initial_ee_position = Point()
    initial_ee_position = future.result().end_effector_position

    controller.get_logger().info('Response received: initial_ee_position_x = %f, initial_ee_position_y = %f' % (initial_ee_position.x, initial_ee_position.y))

    controller.initialize_ee_position(initial_ee_position)

    rclpy.spin(controller)
    
    rclpy.shutdown()


if __name__ == '__main__':
    main()


