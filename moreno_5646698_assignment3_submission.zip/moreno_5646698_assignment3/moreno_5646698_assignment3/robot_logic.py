import rclpy
from rclpy.node import Node
import time

from std_msgs.msg import Int64, Bool
from geometry_msgs.msg import Point

from moreno_5646698_assignment3_interface.srv import ShapeService


class RobotLogic(Node):

    def __init__(self):
        super().__init__("robot_logic_node")

        self.declare_parameter('radius', 50.0)
        self.declare_parameter('number_of_vertices', 4)

        self.radius = self.get_parameter('radius').value
        self.number_of_vertices = self.get_parameter('number_of_vertices').value


        # bool variables to keep track of controllers' state
        self.mot_x_idle = True
        self.mot_y_idle = True

        self.x_coordinates_vertices = []
        self.y_coordinates_vertices = []


        self.next_waypoint = Point()
        self.next_vertix = 0
        

        self.waypoint_pub = self.create_publisher(Point, '/next_waypoint', 10)
        self.draw_pub = self.create_publisher(Bool, '/draw', 10)


        # acks subscribers
        self.ack_x_sub = self.create_subscription(Bool, "/ack_x", self.ack_x_callback, 10)
        self.ack_y_sub = self.create_subscription(Bool, "/ack_y", self.ack_y_callback, 10)


        self.client = self.create_client(ShapeService, '/shape_srv')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service /shape_srv not available, waiting again...')
        self.request = ShapeService.Request()


        # Sleep to allow other nodes to fully initialize before starting time
        time.sleep(5)



    def send_request(self):
        
        self.request.r = self.radius
        self.request.n = self.number_of_vertices

        self.future = self.client.call_async(self.request)
        return self.future


    def ack_x_callback(self, msg: Bool):
        self.mot_x_idle = msg.data

    def ack_y_callback(self, msg: Bool):
        self.mot_y_idle = msg.data


    def start_timer(self, x_coordinates_list, y_coordinates_list):
        self.x_coordinates_vertices = x_coordinates_list
        self.y_coordinates_vertices = y_coordinates_list
        self.motors_state_timer = self.create_timer(1, self.check_idle_motors)


    def check_idle_motors(self):
        # Publish next stage only if both motors are idle
        if self.mot_x_idle and self.mot_y_idle:
            # Reset idle state to avoid infinite loop
            self.mot_x_idle = False
            self.mot_y_idle = False

            self.next_waypoint.x = self.x_coordinates_vertices[self.next_vertix]
            self.next_waypoint.y = self.y_coordinates_vertices[self.next_vertix]

            self.waypoint_pub.publish(self.next_waypoint)

            # Increase internal next vertix var
            self.next_vertix += 1

            if self.next_vertix == 2:
                start_draw_msg = Bool()
                start_draw_msg.data = True
                self.draw_pub.publish(start_draw_msg)

            if self.next_vertix > self.number_of_vertices:
                end_draw_msg = Bool()
                end_draw_msg.data = True
                self.draw_pub.publish(end_draw_msg)
                
                self.motors_state_timer.cancel()
                return



   
def main(args=None):
    rclpy.init(args=args)
    robot_logic = RobotLogic()

    future = robot_logic.send_request()
    rclpy.spin_until_future_complete(robot_logic, future)

    x_coordinates_list = []
    x_coordinates_list = future.result().x_coordinates
    x_coordinates_list.append(x_coordinates_list[0])

    y_coordinates_list = []
    y_coordinates_list = future.result().y_coordinates
    y_coordinates_list.append(y_coordinates_list[0])

    # robot_logic.get_logger().info('Response received: x_coordinates_list = ', x_coordinates_list)
    # robot_logic.get_logger().info('y_coordinates_list = ', y_coordinates_list)


    robot_logic.start_timer(x_coordinates_list, y_coordinates_list)


    rclpy.spin(robot_logic)


    rclpy.shutdown()


if __name__ == '__main__':
    main()


