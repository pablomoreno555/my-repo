from moreno_5646698_assignment3_interface.srv import ShapeService

import rclpy
from rclpy.node import Node

import math

class ServerNode(Node):

    def __init__(self):
        super().__init__('server_node')
        self.srv = self.create_service(ShapeService, '/shape_srv', self.shape_srv_callback)

    def shape_srv_callback(self, request : ShapeService.Request, response : ShapeService.Response):

        self.get_logger().info('Incoming request: r = %f, n = %d' % (request.r, request.n))

        x_list = []
        y_list = []

        for i in range(request.n):

            x_list.append(request.r * math.cos(2*math.pi*i / request.n))
            y_list.append(request.r * math.sin(2*math.pi*i / request.n))

            # response.vertices(i).x = request.r * math.cos(2*math.pi*i / request.n)
            # response.vertices(i).y = request.r * math.sin(2*math.pi*i / request.n)

        response.x_coordinates = x_list
        response.y_coordinates = y_list
        
        return response


def main():
    rclpy.init()
    server_node = ServerNode()

    rclpy.spin(server_node)

    rclpy.shutdown()


if __name__ == '__main__':
    main()
