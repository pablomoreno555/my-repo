from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='moreno_5646698_assignment3',
            executable='printer_sim_node',
            name='printer_node',
        ),
        Node(
            package='moreno_5646698_assignment3',
            executable='motor_x_controller',
        ),
        Node(
            package='moreno_5646698_assignment3',
            executable='motor_y_controller',
        ),
        Node(
            package='moreno_5646698_assignment3',
            executable='shape_service',
        ),
        Node(
            package='moreno_5646698_assignment3',
            executable='robot_logic',
            parameters=[
                {'radius': 100.0},
                {'number_of_vertices': 6},
            ],
        ),
    ])
