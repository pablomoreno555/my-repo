import os
from glob import glob
from setuptools import setup

package_name = 'moreno_5646698_assignment3'
lib = 'moreno_5646698_assignment3/lib'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name, lib],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join("share", package_name, "resource"), glob("resource/*.png")),
        (os.path.join("share", package_name, "launch"), glob("launch/*.launch.py"))
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='simone',
    maintainer_email='simone.maccio@edu.unige.it',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'printer_sim_node = moreno_5646698_assignment3.printer_sim_node:main', 
            'motor_x_controller = moreno_5646698_assignment3.motor_x_controller:main', 
            'motor_y_controller = moreno_5646698_assignment3.motor_y_controller:main', 
            'robot_logic = moreno_5646698_assignment3.robot_logic:main', 
            'shape_service = moreno_5646698_assignment3.shape_service:main', 
        ],
    },
)
